﻿


Select * from AspNetUsers

Select * from AspNetUserRoles

Select * from AspNetRoles

